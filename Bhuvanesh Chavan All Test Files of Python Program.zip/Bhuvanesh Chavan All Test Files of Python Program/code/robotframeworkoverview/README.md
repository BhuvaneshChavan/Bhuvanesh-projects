## Install

``` pip install --upgrade robotframework-seleniumlibrary```

